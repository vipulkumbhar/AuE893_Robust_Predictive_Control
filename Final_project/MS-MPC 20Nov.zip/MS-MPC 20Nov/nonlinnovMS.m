function [c,ceq] = nonlinnovMS(opt,A,B,Xini1,N,tb_d,E)
c             = [];
ceq           = [];

% Per branch
N_constraints = (5+5); % Used for inequality constraints
N_guess       =  22;      % Used for equality constraints definations

jadd          = length(tb_d)*2*N;

for i = 1:N
    % U1 dead zone in -0.1 to 0.1 kW
    c(i) = (- opt(jadd+i)*opt(jadd+i) + 0.1*0.1)*(opt(jadd+i)*opt(jadd+i));
end

for j = 1:length(tb_d)
    
    Xini    = Xini1;                 % X initial for each branch
    tb_dtmp = tb_d(j);               % disturbance for branch
    add     = N_constraints*(j-1);   % for inequality constraints
    add2    = N*2*(j-1);             % no. of guesses, used for equality constraints
    
    for i = 1:N
        
        % 0          = Xk+1 - A*Xk - B*Uk
        % Here assumption is disturbance for 2nd step is added to split
        % into branches, first and 3rd on disturbances are taken as zero
        % if estimated disturbances are available that can be added too
                
        if i>0
            ceq_temp = [opt(i+add) opt(i+N+add)]' - A*Xini - B*([opt(jadd+i) opt(jadd+i+N+1)]')- E*tb_d(j,1);
        else
            ceq_temp = [opt(i+add) opt(i+N+add)]' - A*Xini - B*([opt(jadd+i) opt(jadd+i+N+1)]');
        end
        
        ceq(i+add)   = ceq_temp(1);
        ceq(i+N+add) = ceq_temp(2);
    
        % assign params for next iteration
        Xini         = [opt(i+add);opt(i+N+add)];
    end
    % change in input inequality constraint
    % -20  < d_U1 < 20      dt in sec /1000 [kW]
    % -2.5 < d_U2 < 2 
    % Too big to consider  (Thus ignored here)
end

end