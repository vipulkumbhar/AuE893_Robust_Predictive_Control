% AuE 893 Robust predictive control, Final project, Group 7

%clc;clear;close all
plot_fig = 1;              % Plot result 0-No, 1-Yes
anfig    = 1;              % Animate result 0-No, 1-Yes (if plot_fig = 1 )
an_dt    = 0.5;            % Animation speed

% Load disturbance trajectory
load ('disturbance.mat')
%plot(Pnet);grid on;xlabel('time [30 mins]');ylabel('Power [kW]')

Pnet(22:38) = 0;
Pnet        = Pnet*1;

% States [SOC MHL]'
% Input  [PH2 Pgrid]'
% Disturbance = PV - Pload = Pnet

% Important Parameters
N        = 5;              % Prediction horizon
T_end    = 8.5;            % [Hrs]
dt       = 1*1800/60/60;   % [Hrs]
Xsp      = [60;45];        % State setpoint
Xini     = [70;50];        % Initial state
Q        = 10*eye(2);      % state cost
R        = [5000 0;0 8000];% input cost

Usp      = [0;0];          %((eye(2)-A)*Xsp\B)';
Uini     = [0;0];

% TB MPC
tb_d3    = 0.2;
tb_d     = [-tb_d3;0.0;tb_d3]; % Disturbance that will cause the tree branches
tb_N     = length(tb_d);    % no. of diturbances

% system model
A        = eye(2);
B        = [8.136 5.958;-15.2886 0];
E        = [5.958; 0];
%C        = eye(2);
%D        = zeros(2,2);
%S        = eye(2);
N_mpc    = int8(T_end/dt);

%n_states = length(A);      % number of states
%n_inputs = size(B,2);      % number of inputs
%n_output = size(C,1);      % number of outputs

% Guess for optimization
Xguess   = [Xini(1)*ones(1,N) Xini(2)*ones(1,N)];

tb_Xguess= zeros(1,length(Xguess)*tb_N); % initialize guess for MS-MPC
for i=1:tb_N
    tb_Xguess(1,(i-1)*length(Xguess)+1:i*length(Xguess)) = Xguess;
end
tb_Xguess = [tb_Xguess Usp(1)*ones(1,N+1) Usp(2)*ones(1,N+1)];

% Initialize params
Xall       = zeros(2,N_mpc);
Uall       = zeros(2,N_mpc);
Dall       = zeros(1,N_mpc);
Tall       = 0:0.5:T_end-0.5;
%Xall(:,1)= Xini;
%Uall(:,1)= Uini;
%Dall(:,1)= Pnet(1); 
Uall_traj1 = zeros(1,N,N_mpc);
Uall_traj2 = zeros(1,N,N_mpc);
Xall_traj1 = zeros(tb_N,N+1,N_mpc);
Xall_traj2 = zeros(tb_N,N+1,N_mpc);

% KPI
T_H2       = 0;
T_MHL      = 0;
T_cost     = [0];
T_error    = [0;0];

% Linear inequality constraint
A_ineq     = [];
b_ineq     = [];
    
% Linear equality constraint
Aeq        = [];
beq        = [];
    
% State bounds
% 40   < SOC  < 90
% 10   < MHL  < 90
% -0.9 < U1   < 0.9
% -2.5 < U2   < 2.0
% Lower bounds definition
lb_x1      = 40*ones(1,N);         % Lower bound for state x1
lb_x2      = 10*ones(1,N);         % Lower bound for state x2
lb_u1      = -0.9*ones(1,N+1);     % Lower bound for control input u1
lb_u2      = -2.5*ones(1,N+1);     % Lower bound for control input u2
    
% Upper bounds definition
ub_x1      = 90*ones(1,N);         % Upper bound for state x1
ub_x2      = 90*ones(1,N);         % Upper bound for state x2
ub_u1      = 0.9*ones(1,N+1);      % Upper bound for control input u1
ub_u2      = 2*ones(1,N+1);        % Upper bound for control input u2
    
% Lower and upper bounds for all the optimization variables
lb         = [lb_x1 lb_x2];
ub         = [ub_x1 ub_x2];  
tb_lb      = [];%zeros(1,tb_N*2*N+2*(N+1));
tb_ub      = [];%zeros(1,tb_N*2*N+2*(N+1));

for j=1:tb_N
    tb_lb =[tb_lb lb];
    tb_ub =[tb_ub ub];
end
tb_lb =[tb_lb lb_u1 lb_u2];
tb_ub =[tb_ub ub_u1 ub_u2];

% Start MPC loop
tic   
tb_d2 = tb_d;
ptemp = -0.5;
jadd =tb_N*2*N;
    
for i    = 1:N_mpc
      
    % Modify disturbance values
    if i ~=1
        ptemp = Pnet(i-1);
    end
    
    if Pnet(i) - ptemp>0
        tb_d = tb_d2 + ptemp + tb_d3;
        
    elseif Pnet(i) - ptemp<0
        tb_d = tb_d2 + ptemp - tb_d3;  
    else
        tb_d = tb_d2+ptemp;
    end
    
    % fmincon optimization options
    options    = optimoptions('fmincon','Display','none','Algorithm','interior-point',....
        'MaxFunctionEvaluations',30000);
    nonlcon    = @nonlinnovMS;
    call_fun   = @objective_functionnovMS;
    
    % fmincon NLP solver
    % opt_var - optimized variable output, fval - function value
    % quadprog can be used here (Faster than fmincon)
    [opt_var, fval] = fmincon(@(opt)call_fun(opt,Q,R,Xsp,Usp,N,tb_d),...
        tb_Xguess,A_ineq,b_ineq,Aeq,beq,tb_lb,tb_ub,@(opt)nonlcon(opt,A,B,Xini,N,tb_d,E),options);
    
    % Initial guess for optimization variables for the next prediction horizon

    U          = [opt_var(jadd+1); opt_var(jadd+1+N+1)];
    
    % save inputs of each branch
    Uall_traj1(1,:,i) = opt_var(jadd+1:jadd+N);
    Uall_traj2(1,:,i) = opt_var(jadd+2+N:jadd+1+N+N);
    
    for l = 1:tb_N
        ladd       = N*2*(l-1); 
        Xall_traj1(l,:,i) =[Xini(1) tb_Xguess(1+ladd:N+ladd)];
        Xall_traj2(l,:,i) =[Xini(2) tb_Xguess(1+5+ladd:N+5+ladd)];
    end

    % Simulate system with first input
    mpc_sim    = A*Xini + B*U + E*Pnet(i);
    
    % Assign params for next iteration
    Xini       = mpc_sim;
    Uini       = U;
    tb_Xguess  = opt_var;
    
    % Save the states and inputs
    Xall(:,i)= mpc_sim;
    Uall(:,i)= U; 
    Dall(:,i)= Pnet(i);
    
    % KPI (if U are non-zero
    if abs(U(1)) > 0.09
        T_H2    = T_H2 + 30*60;
    end
    if abs(U(2)) > 0.001
        T_MHL    = T_MHL + 30*60;
    end
    
    % Cumulative cost (Not the actual cost)
    T_cost(i)  = T_cost(end) + (Xini-Xsp)'*Q*(Xini-Xsp) + (U - Usp)'*R*(U - Usp);
    T_error    = T_error + sqrt((mpc_sim - Xsp).*(mpc_sim - Xsp));
end
toc


% params conversion for plots      % CHECK / IMPORTANT
Uall           = Uall*1000;        % kW to watt
Uall_traj1     = Uall_traj1 *1000;
Uall_traj2     = Uall_traj2 *1000;

%% KPI's
txt_time = num2str(toc);
txt_th2  = num2str(T_H2);
txt_mhl  = num2str(T_MHL);
txt_tc   = num2str(T_cost(end));

fprintf('\nComputational time required to solve optimization = %s seconds.', txt_time)
fprintf('\nTime for which fuel cell is operating             = %s seconds.', txt_th2)
fprintf('\nTime for which electrolyzer is operating          = %s seconds.', txt_mhl)
fprintf('\n\nFinal cumulative cost is %s .\n', txt_tc)
fprintf('\nFinal value of SOC and MHL:')
mpc_sim

fprintf('\nAvg. tracking error of SOC and MHL')
avg_error = T_error*(1/double(N_mpc))

%% Simple Plot
U1_deadzone     = [-100,100]'*ones(1,length(Tall));
U1_constraints  = [-900,900]'*ones(1,length(Tall));
Xsall           = Xsp.*ones(2,N_mpc);       % states ref line
Usall           = Usp.*ones(2,N_mpc);       % input ref line

xn = N;
plt_mkr = {'r--';'g--';'b--';'y--';'v--';'c--';'r--';'g--';'b--';'y--';'v--';'c--'};

n   = length(Tall);
i_start = 1;
if anfig  == 0              % Animate result 0-No, 1-Yes
    i_start = n;
end

%Initialize video
msmpcVideo = VideoWriter('msmpcVideoFile','MPEG-4'); %open video file
msmpcVideo.FrameRate = 1;  %can adjust this, 5 - 10 works well
open(msmpcVideo)

if plot_fig == 1
    fig = figure('name','TB-MPC Simulation Results');
    for i=i_start:n
        if (n-1) - i<4
            xn = (n-1) - i+2;
        end
        
        subplot(3,2,1)
        plot (Tall(1:i) ,Xall(1,1:i),'b','LineWidth',2);hold on
        if (i>1) && (i<n)
            for dn = 1:tb_N
                stairs(Tall(i-1:i+xn-1),Xall_traj1(dn,1:xn+1,i),plt_mkr{dn},'LineWidth',1);hold on  % plot prediction horizon
            end
        end
        plot (Tall,Xsall(1,:),'b--','LineWidth',1);grid on
        xlabel('Time [Hrs]');ylabel('SOC [%]');axis([0 Tall(end) 53 82])
        % legend('SOC','SOC ref')
    
        subplot(3,2,3)
        plot (Tall(1:i) ,Xall(2,1:i),'r','LineWidth',2);hold on
        if (i>1) && (i<n)
            for dn = 1:tb_N
                stairs(Tall(i-1:i+xn-1),Xall_traj2(dn,1:xn+1,i),plt_mkr{dn},'LineWidth',1);hold on  % plot prediction horizon
            end
        end
        plot (Tall,Xsall(2,:),'r--','LineWidth',1);grid on
        xlabel('Time [Hrs]');ylabel('MHL [%]');axis([0 Tall(end) 40 57])
    
        subplot(3,2,2)
        stairs(Tall(1:i) ,Uall(1,1:i) ,'b','LineWidth',2);hold on;grid on
        for dn = 1:1
            stairs(Tall(i:i+xn-1),Uall_traj1(dn,1:xn,i),plt_mkr{dn},'LineWidth',1);hold on  % plot prediction horizon
        end
        stairs(Tall ,Usall(1,:),'b--','LineWidth',1);hold on
        plot(Tall ,U1_deadzone(1,:),'k:','LineWidth',1);hold on
        plot(Tall ,U1_deadzone(2,:),'k:','LineWidth',1);hold on
        axis([0 Tall(end) -200 200]);xlabel('Time [Hrs]');ylabel('PH2 [W]');
    
        subplot(3,2,4)
        stairs(Tall(1:i) ,Uall(2,1:i) ,'r','LineWidth',2);hold on;grid on
        plot(Tall ,Usall(2,:),'r--','LineWidth',1);grid on
        for dn = 1:1
            stairs(Tall(i:i+xn-1),Uall_traj2(dn,1:xn,i),plt_mkr{3},'LineWidth',1);hold on  % plot prediction horizon
        end
        axis([0 Tall(end) min(Uall(2,:)) max(Uall(2,:))]);xlabel('Time [Hrs]');ylabel('PGrid [W]');
    
        subplot(3,2,6)
        stairs(Tall(1:i),Dall(1:i),'k','LineWidth',2);grid on
        xlabel('Time [Hrs]');ylabel('Pnet [kW]');axis([0 Tall(end) min(Dall) max(Dall)])  
        % legend('Pnet')

        subplot(3,2,5)
        plot(Tall(1:i),T_cost(1:i),'k','LineWidth',2);grid on
        xlabel('Time [Hrs]');ylabel('Cummulative cost');axis([0 Tall(end) min(T_cost) max(T_cost)]) 
        
        pause(an_dt)
        frame = getframe(gcf);
        writeVideo(msmpcVideo, frame);
        
        if i<n
            clf(fig)
        end
    end
end

close(msmpcVideo)

%% The End