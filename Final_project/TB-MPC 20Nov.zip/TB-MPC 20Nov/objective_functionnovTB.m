function [opt_fun] = objective_functionnovTB(opt,Q,R,Xsp,Usp,N,tb_d)

N_guess       = 22;
opt_fun       = 0;

for j = 1:length(tb_d)  % No. of branches
    
    add = (j-1)*N_guess;% no. of params in opts of each tree 
    % V = 0.5* ( square(X-X_setpoint)|Q + square(U-U_setpoint)|R )
    for i = 1:N
        opt_fun = opt_fun ...
            + 0.5*(([opt(i+add); opt(i+N+add)] - Xsp)')*Q*([opt(i+add);opt(i+N+add)] - Xsp)...
            + 0.5*(([opt(i+2*N+add);opt(i+3*N+1+add)] - Usp)')*R*([opt(i+2*N+add);opt(i+3*N+1+add)] - Usp);
    end
end

opt_fun = opt_fun /size(tb_d,1);

end