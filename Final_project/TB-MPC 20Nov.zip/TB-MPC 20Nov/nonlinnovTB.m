function [c,ceq] = nonlinnovTB(opt,A,B,Xini1,N,tb_d,E)
c             = [];
ceq           = [];

% Per branch
N_constraints = (5+5+6); % Used for inequality constraints
N_guess       = 22;      % Used for equality constraints definations

for j = 1:length(tb_d)
    
    Xini    = Xini1;                 % X initial for each branch
    tb_dtmp = tb_d(j);               % disturbance for branch
    
    add     = N_constraints*(j-1);   % for inequality constraints
    add2    = N_guess*(j-1);         % no. of guesses, used for equality constraints
    
    for i = 1:N
        % U1 dead zone in -0.1 to 0.1 kW
        c(i+2*N+add) = (- opt(2*N+i+add2)*opt(2*N+i+add2) + 0.1*0.1)*(opt(2*N+i+add2)*opt(2*N+i+add2)); % check
        
        % 0          = Xk+1 - A*Xk - B*Uk
        % if estimated disturbances are available that can be added in else
        % statement equation
        
        % For first input to be same, disturbance added for first input
        % should also be same to satisfy (0= Xk+1 - A*Xk - B*Uk - E*W)
        
        if i>1
            ceq_temp     = [opt(i+add2) opt(i+N+add2)]' - A*Xini - B*([opt(2*N+i+add2) opt(3*N+1+i+add2)]')- E*tb_d(j,1);
        else
            ceq_temp     = [opt(i+add2) opt(i+N+add2)]' - A*Xini - B*([opt(2*N+i+add2) opt(3*N+1+i+add2)]');
        end
        
        ceq(i+add)   = ceq_temp(1);
        ceq(i+N+add) = ceq_temp(2);
    
        % assign params for next iteration
        Xini         = [opt(i+add2);opt(i+N+add2)];
    end
    % change in input inequality constraint
    % -20  < d_U1 < 20      dt in sec /1000 [kW]
    % -2.5 < d_U2 < 2 
    % Too big to consider  (Thus ignored here)
end


if j>1 % If there is a branch
    % First inputs are same
    for k = 1:j-1
        ceq(i+2*N+add+2*k-1)   = opt(22*(k-1)+2*N+1) - opt(22*(k)+2*N+1); % first of U1 are same
        ceq(i+2*N+add+2*k)     = opt(22*(k-1)+3*N+2) - opt(22*(k)+3*N+2); % first of U2 are same
    end
end

end